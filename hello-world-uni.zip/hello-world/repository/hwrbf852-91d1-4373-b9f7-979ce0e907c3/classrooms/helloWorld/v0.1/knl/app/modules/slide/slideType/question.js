'use strict';

var app = angular.module('knlClassroom');

app.controller('QuestionSlideController', [
	'$scope',
	'$sce',
	function($scope, $sce) {

		$scope.sce = $sce;

		$scope.solve = function(){
			if($scope.answerCorrect){
            	doLMSSetValue('knl.next', 'true');
				return;
			}
			$scope.answerCorrect = false;
			var questionCorrect = 0;
			for (var i = 0; i < $scope.slide.options.length; i++){
				var option = $scope.slide.options[i];
				option.selected = option.selected || false;
				option.expected = option.expected || false;
				if(option.selected == option.expected){
					questionCorrect++;
				}
			}
			$scope.answerCorrect = $scope.answerCorrect || questionCorrect == $scope.slide.options.length;
		};

		$scope.clear = function(optionClicked){
			if(!$scope.slide.isMultiple){
				for (var i = 0; i < $scope.slide.options.length; i++){
					var option = $scope.slide.options[i];
					option.selected = (optionClicked.text == option.text);
				}
			}
			$scope.answerCorrect = null;
		};

	}
]);
