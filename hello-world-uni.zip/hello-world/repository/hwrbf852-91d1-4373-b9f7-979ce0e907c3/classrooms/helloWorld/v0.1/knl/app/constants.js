'use strict';

var app = angular.module('knlClassroom');

app.constant('SLIDE_TYPE', {
    VIDEO: 'video',
    QUESTION: 'question',
    FINAL_EXAM: 'finalExam',
    BUBBLE: 'bubble'
});

app.constant('CLASSROOM_PATH', '../classroom/');