'use strict';

var app = angular.module('knlClassroom', [
    'ngRoute'
]);

app.config([
    '$routeProvider', 
    '$locationProvider', 
    function($routeProvider, $locationProvider) {
        $routeProvider.when('/slide', {
            templateUrl: 'app/modules/slide/slide.html',
            controller: 'SlideController'
        })
        .otherwise({
            redirectTo: '/slide'
        });
}]);

app.directive('aDisabled', function() {
    return {
        compile: function(tElement, tAttrs, transclude) {
            //Disable ngClick
            tAttrs["ngClick"] = "!("+tAttrs["aDisabled"]+") && ("+tAttrs["ngClick"]+")";

            //Toggle "disabled" to class when aDisabled becomes true
            return function (scope, iElement, iAttrs) {
                scope.$watch(iAttrs["aDisabled"], function(newValue) {
                    if (newValue !== undefined) {
                        iElement.toggleClass("disabled", newValue);
                    }
                });

                //Disable href on click
                iElement.on("click", function(e) {
                    if (scope.$eval(iAttrs["aDisabled"])) {
                        e.preventDefault();
                    }
                });
            };
        }
    };
});

app.run([
    '$rootScope',
    '$location',
    '$http',
    '$timeout',
    'CLASSROOM_PATH',
    function($rootScope, $location, $http, $timeout, CLASSROOM_PATH) {

        $http.get(CLASSROOM_PATH + 'knl.json').success(function(classroomInfo) {
            classroomInfo.slides = [];
            angular.forEach(classroomInfo.topics, function(topic){
                angular.forEach(topic.slides, function(slide){
                    classroomInfo.slides.push(slide);
                });
            });

            $rootScope.classroomInfo = classroomInfo;
            
            $timeout(function(){
                $rootScope.$broadcast('classroomInfoFetched', $rootScope.classroomInfo);
            });
        });

        $rootScope.$on('$locationChangeSuccess', function(next, current) {
            //ga('send', 'pageview', location.hash.substring(2, location.hash.length));
            window.scrollTo(0, 0);
        });

    }
]);