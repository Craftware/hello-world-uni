'use strict';

var app = angular.module('knlClassroom');

app.controller('FinalExamSlideController', [
	'$scope',
	'$sce',
	function($scope, $sce) {

		$scope.sce = $sce;

		$scope.init = function(){
	        $scope.score = $scope.doLMSGetValueSanitized('cmi.core.score.raw');
	        $scope.isApproved = $scope.doLMSGetValueSanitized('knl.isApproved');
	        $scope.currentScore = $scope.doLMSGetValueSanitized('knl.currentScore');
	        $scope.showPanel = 'intro';
            if($scope.isApproved !== 'true'){
                doLMSSetValue('knl.'+$scope.slideNumber+'.nextEnabled', 'false');
            }
	    };		

        $scope.loadQuestion = function(currentQuestionIndex) {
        	if(currentQuestionIndex && !$scope.hasAccessToQuestion(currentQuestionIndex)) return;
            $scope.currentQuestionIndex = currentQuestionIndex;
            $scope.currentQuestion = $scope.slide.questions[$scope.currentQuestionIndex];
        };
        
        $scope.loadNext = function(){
            $scope.loadQuestion($scope.currentQuestionIndex+1);
        };

        $scope.loadPrevious = function(){
            $scope.loadQuestion($scope.currentQuestionIndex-1);
        };

        $scope.finishTest = function(){
            $scope.cmiScoreRaw = 0;//cmi.score.raw
            $scope.classroomInfo.expectedGrade = $scope.classroomInfo.expectedGrade || 0;

            $scope.totalCorrect = 0;
            $scope.questionCount = $scope.slide.questions.length;

            for (var i = 0; i < $scope.slide.questions.length; i++){
                var questionOptions = $scope.slide.questions[i].options;
                var questionCorrect = 0;
                for (var j = 0; j < questionOptions.length; j++){
                    var option = questionOptions[j];
                    option.expected = option.expected || false;
                    option.selected = option.selected || false;
                    if(option.expected == option.selected){
                        questionCorrect++;
                    }
                }
                if(questionCorrect == questionOptions.length){
                    $scope.totalCorrect++;
                }
            }

            $scope.cmiScoreRaw = (($scope.totalCorrect*100)/$scope.questionCount);
            $scope.cmiScoreRaw = Math.round($scope.cmiScoreRaw);
            $scope.currentScore = $scope.currentScore > $scope.cmiScoreRaw ? $scope.currentScore : $scope.cmiScoreRaw;

            doLMSSetValue('cmi.core.score.raw', $scope.cmiScoreRaw);
            doLMSSetValue('knl.currentScore', $scope.currentScore);

            $scope.isApproved = ($scope.cmiScoreRaw >= $scope.classroomInfo.expectedGrade);
            if(!$scope.isApproved){
                doLMSSetValue('knl.'+$scope.slideNumber+'.nextEnabled', 'true');
                doLMSSetValue('knl.isApproved', 'true');
            }
            $scope.showPanel = 'result';
        };

    	$scope.isQuestionAnswered = function(question){
    		//questions with multiple options are always answered, since they can be all false
			var isAnswered = $scope.slide.isMultiple;		
			for (var i = 0; i < question.options.length; i++){
				var option = question.options[i];
				isAnswered = isAnswered || option.selected;
			}
			return isAnswered;
    	};

        $scope.hasAccessToQuestion = function(index){
        	$scope.blah = [];
			var hasAccessToQuestion = true;
			if($scope.currentQuestion){
				if($scope.isApproved === 'true'){
					$scope.blah[index] = 1;
					//if is approved, access is granted
					hasAccessToQuestion = true;
				} else if($scope.currentQuestionIndex >= index){
					$scope.blah[index] = 2;
					//if it's before the current question, access is granted
					hasAccessToQuestion =  true;
				} else if(($scope.currentQuestionIndex + 1) == index){
					$scope.blah[index] = 3;
					//if it's the next question, only allow if current question is answered
					hasAccessToQuestion = $scope.isQuestionAnswered($scope.currentQuestion);
				} else {
					//otherwise allow if the previous question is answered
					$scope.blah[index] = 4;
					hasAccessToQuestion = $scope.isQuestionAnswered($scope.slide.questions[index - 1]);
				}
			}
			return hasAccessToQuestion;
        };

        $scope.startTest = function(){
            $scope.showPanel = 'main';
            $scope.loadQuestion(0);

            for (var i = 0; i < $scope.slide.questions.length; i++){
                var questionOptions = $scope.slide.questions[i].options;
                for (var j = 0; j < questionOptions.length; j++){
                    var option = questionOptions[j];
                    option.selected = false;
                }
            }
        };

        $scope.next = function(){
            doLMSSetValue('knl.next', 'true');
        };

        $scope.doLMSGetValueSanitized = function(key){
            var value = doLMSGetValue(key);
            return value && value != 'null' ? value : null;
        };

		$scope.clear = function(optionClicked){
			if(!$scope.slide.isMultiple){
				for (var i = 0; i < $scope.currentQuestion.options.length; i++){
					var option = $scope.currentQuestion.options[i];
					option.selected = (optionClicked.text == option.text);
				}
			}
			$scope.answerCorrect = null;
		};

        $scope.init();

	}
]);
