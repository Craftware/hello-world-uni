'use strict';

var app = angular.module('knlClassroom');

app.controller('SlideController', [
	'$scope',
	'$timeout',
	'$location',
	'CLASSROOM_PATH',
	function($scope, $timeout, $location, CLASSROOM_PATH) {
		$scope.CLASSROOM_PATH = CLASSROOM_PATH;

		$scope.initSlide = function(){
			if($scope.slide || !$scope.classroomInfo) return;

			$scope.slideNumber = $location.$$search.s || 0;
			$scope.slide = $scope.classroomInfo.slides[$scope.slideNumber];

			if($scope.classroomInfo.colorBackground){
				$scope.bgStyle = 'background-color: '+$scope.classroomInfo.colorBackground+';';
			} else {
				$scope.bgStyle = 'background: url('+CLASSROOM_PATH+'images/knlDefaultSlideBG.jpg) no-repeat center center fixed;';				
			}

			var slideIndex = 0;
	        angular.forEach($scope.classroomInfo.topics, function(topic){
	            angular.forEach(topic.slides, function(slide){
	            	if($scope.slideNumber == slideIndex++){
	            		$scope.topic = topic;
	            	}
	            });
	        });
		};

    	$scope.$on('classroomInfoFetched', function(event, classroomInfo) { 
			$timeout(function(){
				$scope.initSlide();

				var slideIndex = 0;
				$scope.structureDebug = '';
		        angular.forEach(classroomInfo.topics, function(topic){
		            $scope.structureDebug += ( $scope.structureDebug.length == 0 ? '' : '\n') + ('# ' + topic.title);
		            angular.forEach(topic.slides, function(slide){
		            	$scope.structureDebug += ('\nknl/knl.html#/slide?s=' + (slideIndex++) + ';' + slide.title);
		            });
		        });
		        $scope.structureDebug.trim();
		        $scope.isToggleStructureDebug = ((window.location.hostname == 'localhost' ||
		        	window.location.hostname.split('.')[0].endsWith('-homolog')) ? false : null);
			});
    	});

    	$scope.toggleStructureDebug = function(){
		    $scope.isToggleStructureDebug = !$scope.isToggleStructureDebug;
    	}

    	$scope.initSlide();
	}
]);
